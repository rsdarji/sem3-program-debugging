import text_formatter


def test_join_lines():
    ...


def test_get_lines_of_length():
    ...


def test_create_new_filename():
    ...


if __name__ == "__main__":
    test_join_lines()
    test_get_lines_of_length()
    test_create_new_filename()
