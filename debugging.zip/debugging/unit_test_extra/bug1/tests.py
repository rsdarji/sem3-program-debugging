import truck_loading


def test_read_file_content():
    ...


def test_split_items():
    ...


if __name__ == "__main__":
    test_read_file_content()
    test_split_items()