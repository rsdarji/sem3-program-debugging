import html_formatter


def test_is_closing_tag():
    ...


def test_is_opening_tag():
    ...


def test_format_with_indentation():
    ...


if __name__ == "__main__":
    test_is_closing_tag()
    test_is_opening_tag()
    test_format_with_indentation()
